basicModule.controller('basicController',function($scope){
    //$scope.Message = "Hello World !"; // model
    $scope.Person = {
        Name:'Virat',
        Age:26,
        ImageUrl:'http://images.indianexpress.com/2016/05/virat1.jpg'
    }
    $scope.ChangeName = function(){
        $scope.Person.Name = "Virat Kohli";               
    }
})