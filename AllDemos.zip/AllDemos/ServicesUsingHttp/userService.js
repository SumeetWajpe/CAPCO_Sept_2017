userModule.factory('userDataSVC',function($http,$q){
        return{
            getData:function(){
                // make ajaxified request here |  using $http
                var defer = $q.defer();
                $http({
                    method:'GET',
                    url:'https://jsonplaceholder.typicode.com/uers'
                }).then(function(response){
                    //console.log(response.data);
                    defer.resolve(response.data);
                },
                function(error){
                    //console.log(response.data);
                    defer.reject(error);
                });

                return defer.promise; // return a promise
            }
        }
})