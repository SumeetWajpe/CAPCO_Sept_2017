userModule.controller('userController',function($scope,userDataSVC){
    $scope.Title = "Users";
   var returnedPromise = userDataSVC.getData();
   returnedPromise.then(function(dataFromService){
        $scope.users = dataFromService;
   },
   function(error){
    console.log(error)
})

})