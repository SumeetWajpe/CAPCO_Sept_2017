userModule.directive('userInformation',function(){
    return{
       // template:'<h1> Using Custom Directive ! </h1>',
       templateUrl:'TemplateForDirective.html',
        restrict:'EAC'
    }
})