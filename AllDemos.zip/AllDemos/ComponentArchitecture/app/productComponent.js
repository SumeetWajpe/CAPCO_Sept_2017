shoppingCartModule.component('product',{
    template:'<h3> {{ $ctrl.pdetails.Name}}  </h3>',
    bindings:{
            pdetails:'<'
    }
});