trainingModule.controller('trainingController',function($scope,trainingDataSvc){
    $scope.TrainingDetails = trainingDataSvc.getData();

    $scope.ClassToBeApplied = "Details";
    $scope.StyleToBeApplied = {backgroundColor:'lightblue'};
    $scope.IsSuccess = true;
    $scope.IsFree = false;
    $scope.CheckedHandler = function(evt){
        console.log(evt)
    }


        $scope.Companies = [

                {Name:'Accenture',Location:'Hyderabad'},
                {Name:'Accenture',Location:'Pune'},
                {Name:'CAPCO',Location:'Bengaluru'},
                {Name:'CAPCO',Location:'Pune'},
                {Name:'Accenture',Location:'Mumbai'}      

        ];



        $scope.Cities = [
            {Name:'Pune',Speciality:'Misal Paav'},
            {Name:'Hyderabad',Speciality:'Biryani'},
            {Name:'Mumbai',Speciality:'Wada Paav'},
            {Name:'Nagpur',Speciality:'Tarri Poha'}            
        ];



    $scope.Skills = [
        {SkillName:'ReactJS',Duration:'3 Days'},
        {SkillName:'AngularJS',Duration:'3 Days'},
        {SkillName:'NodeJS',Duration:'4 Days'}        
        ];

        $scope.IncrementLikes = function(passedTopic){
            passedTopic.Likes=passedTopic.Likes + 1;            
        }

        $scope.DecrementLikes = function(passedTopic){
            passedTopic.Likes=passedTopic.Likes - 1;            
        }


        
    // $scope.HandleChangeOfTextBox = function(evt){
    //    $scope.TrainingDetails.Title = evt.target.value;
    // }
})