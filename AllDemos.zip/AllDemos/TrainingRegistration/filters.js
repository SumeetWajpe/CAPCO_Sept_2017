trainingModule.filter('cutshort',function(){

    return function(inputFromView,numOfChar){

        var maxLimit = numOfChar ? numOfChar : 50
            return inputFromView.substring(0,maxLimit) + '...';
    }



})