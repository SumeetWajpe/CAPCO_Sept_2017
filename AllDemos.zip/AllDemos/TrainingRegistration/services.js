
// function trainingSVC(){
//     this.getData = function(){
//         return  {
//             Title:'Angular JS',   
//             Price:3000,
//             TrainingDate:new Date(),
//             Duration:'3 Days',
//             Location:'Pune',
//             Trainer:'Sumeet',
//             ImageUrl:'http://voidcanvas.com/wp-content/uploads/2015/10/angularjs-logo.png',
//             Topics:[
//                     {Name:'Introduction to Angular JS',Level: 'Beginner',      
//                    Rating:2,
//                   Duration:'2 Hours',
//                     Likes:10,
//                     Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`
//                 },
        
//                     {Name:'Introduction to Binding',Level: 'Intermediate',      
//                     Rating:3.5878,
//                    Duration:'3 Hours',
//                      Likes:110,  Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`},
        
//                      {Name:'Using Directives',Level: 'Beginner',      
//                      Rating:2,
//                     Duration:'1 Hour',
//                       Likes:100,  Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`},
        
                      
//                      {Name:'Using Services',Level: 'Advanced',      
//                      Rating:5,
//                     Duration:'3 Hours',
//                       Likes:10,
//                       Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`},
                      
//                      {Name:'Using Filters',Level: 'Beginner',      
//                      Rating:4,
//                     Duration:'1 Hour',
//                       Likes:50,
//                       Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`}
//             ]
                
//             }
//     }
// }


// trainingModule.service('trainingDataSvc',trainingSVC);

// class Car{
//     Accelerate(){
//         return 100;
//     }
// }

// trainingModule.service('trainingDataSvc',Car);



var trainingSVC = function(){
    return{
        getData:function(){
            return {
                            Title:'Angular JS',   
                            Price:3000,
                            TrainingDate:new Date(),
                            Duration:'3 Days',
                            Location:'Pune',
                            Trainer:'Sumeet',
                            ImageUrl:'http://voidcanvas.com/wp-content/uploads/2015/10/angularjs-logo.png',
                            Topics:[
                                    {Name:'Introduction to Angular JS',Level: 'Beginner',      
                                   Rating:2,
                                  Duration:'2 Hours',
                                    Likes:10,
                                    Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`
                                },
                        
                                    {Name:'Introduction to Binding',Level: 'Intermediate',      
                                    Rating:3.5878,
                                   Duration:'3 Hours',
                                     Likes:110,  Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`},
                        
                                     {Name:'Using Directives',Level: 'Beginner',      
                                     Rating:2,
                                    Duration:'1 Hour',
                                      Likes:100,  Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`},
                        
                                      
                                     {Name:'Using Services',Level: 'Advanced',      
                                     Rating:5,
                                    Duration:'3 Hours',
                                      Likes:10,
                                      Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`},
                                      
                                     {Name:'Using Filters',Level: 'Beginner',      
                                     Rating:4,
                                    Duration:'1 Hour',
                                      Likes:50,
                                      Summary:`HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting environment is extraordinarily expressive, readable, and quick to develop.`}
                            ]
                                
                            }
        }
    }
}

trainingModule.factory('trainingDataSvc',trainingSVC);


