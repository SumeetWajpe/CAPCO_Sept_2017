trainingModule.controller('trainingController',function($scope){
    $scope.TrainingDetails = {
    Title:'Angular JS',   
    Price:3000,
    Duration:'3 Days',
    Location:'Pune',
    Trainer:'Sumeet',
        ImageUrl:'http://voidcanvas.com/wp-content/uploads/2015/10/angularjs-logo.png'
        
    }

    $scope.ClassToBeApplied = "Details";
    $scope.StyleToBeApplied = {backgroundColor:'lightblue'};
    $scope.IsSuccess = true;
    $scope.IsFree = false;
    $scope.CheckedHandler = function(evt){
        console.log(evt)
    }
    // $scope.HandleChangeOfTextBox = function(evt){
    //    $scope.TrainingDetails.Title = evt.target.value;
    // }
})